<?php 
include_once "header.php";  

$vid=$_GET['vid'];    // read query string

require_once "db_conf.php";

$query="select * from veg where vid='$vid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$vname=$row['vname'];
}
else
	exit("<h2>Record Not Found</h2>");

?>

<h2 class='msg' style='color:red'>Delete veg: <?php echo $vname; ?></h2>

<p><a class='link' href='veg_list.php'>Back To List</a></p>
<form action='act_del_veg.php' method='post'>

<input type='hidden' name='vid' value="<?php echo $vid; ?>" /></td>
<h3 class='msg'>Are You Sure?</h3>
<input type='submit' value='Confirm Delete' />

</form>
<?php 
include_once "footer.php";  
?>