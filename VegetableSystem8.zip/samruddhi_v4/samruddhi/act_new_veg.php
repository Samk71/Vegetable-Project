<?php 
include_once "header.php";  

$vname=$_POST['vname'];
$unit=$_POST['unit'];
$rate=$_POST['rate'];

require_once "db_conf.php";

$query="insert into veg(vid,vname,unit,rate) values(null,'$vname','$unit','$rate')";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
{
	echo "<h3 class='msg'>SUCCESS: Vegetable Added</h3>";
	echo  "<p><a class='link' href='veg_list.php'>Back To List</a></p>";
}

include_once "footer.php";  
?>