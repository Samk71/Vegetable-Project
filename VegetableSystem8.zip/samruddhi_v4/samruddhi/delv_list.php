<?php 
include_once "header.php";  
?>
<p>

<a class='link' href='new_delv.php'>New Delivery</a>
</p>
<table border="1" cellpadding="15" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='khaki'><th colspan='9'>Delivery List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>Delivery id</th><th>Delivery Date</th><th>OID</th><th>Notes</th><th>Action</th></tr>

<?php
require_once"db_conf.php";

$query="select * from delivery order by did desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
	$did=$row['did'];
    	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td align='center'>$did</td>";
	echo "<td>".$row['ddt']."</td>";
	echo "<td>".$row['oid']."</td>";
	echo "<td>".$row['notes']."</td>";
    echo "<td>";
           
	echo "&nbsp;&nbsp;<a href='del_delv.php?did=$did'>Delete</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>