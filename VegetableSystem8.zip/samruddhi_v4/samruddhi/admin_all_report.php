<?php include_once  "header.php";

if($g_role!='admin')
{
	exit("<h2 class='msg' style='color:red'>Access Denied. Please Login</h2>");
}
 ?>
<div class='msg'>
<h2>Welcome To Admin Action Panel</h2>
<ol style='text-align:left'>
<li><p>To View Customer Reports <a href='admin_reports.php'>Click Here</a></p></li>
<li><p>To View Supplier Reports <a href='admin_supplier_report.php'>Click Here</a></p></li>
<li><p>To View Vegetable Reports <a href='admin_vegetable_report.php'>Click Here</a></p></li>
<li><p>To View Specific Vegetable Reports <a href='admin_specific_veg_report.php'>Click Here</a></p></li>
<li><p>To View Receipt Reports <a href='admin_recp_report.php'>Click Here</a></p></li>
<li><p>To View Delivery Reports <a href='admin_delv_report.php'>Click Here</a></p></li>
<li><p>To View Feedback Reports <a href='admin_feedback_report.php'>Click Here</a></p></li>

<li><p><a href='logout.php'>Logout</a></p></li>
</ol>
</div>
<?php include_once  "footer.php" ?>
