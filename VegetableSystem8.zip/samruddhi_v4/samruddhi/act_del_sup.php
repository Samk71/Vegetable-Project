<?php 
include_once "header.php";  

$sid=$_POST['sid'];

require_once "db_conf.php";

$query="delete from supplier where sid='$sid'";

mysqli_query($con,$query) or die("<h3 style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
	echo "<h3 class='msg'>SUCCESS: Supplier Deleted</h3>";
else
	echo "<h3 class='msg'>Oopsss: Record Not Found</h3>";
	
echo  "<p><a class='link' href='sup_list.php'>Back To List</a></p>";

include_once "footer.php";  
?>