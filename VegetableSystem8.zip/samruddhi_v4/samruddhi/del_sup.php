<?php 
include_once "header.php";  

$sid=$_GET['sid'];    // read query string

require_once "db_conf.php";

$query="select * from supplier where sid='$sid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$sname=$row['sname'];
}
else
	exit("<h2>Record Not Found</h2>");

?>

<h2 class='msg' style='color:red'>Delete supplier: <?php echo $sname; ?></h2>

<p><a class='link' href='sup_list.php'>Back To List</a></p>
<form action='act_del_sup.php' method='post'>

<input type='hidden' name='sid' value="<?php echo $sid; ?>" /></td>
<h3 class='msg'>Are You Sure?</h3>
<input type='submit' value='Confirm Delete' />

</form>
<?php 
include_once "footer.php";  
?>