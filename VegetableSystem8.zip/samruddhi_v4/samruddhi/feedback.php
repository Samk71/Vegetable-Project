<?php include_once  "header.php" ?>
<form action="act_feedback.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' style="background:aliceblue">
<tr bgcolor='pink'><th colspan='4'>Feedback</th></tr>
<tr>
<th>Full Name:</th>
<td><input type="text" name="fullname" required /></td>
</tr>
<tr>
<th>Email:</th>
<td><input type="email" name="email" required/></td>
</tr>
<tr>
<th>Mobile No:</th>
<td><input type="varchar" name="mobile" required/></td>
</tr>
<tr>
<th>Write Feedback Here :</th>
<td>
<textarea name="feedback" rows="3" cols="21" required></textarea>
</td>
</tr>
<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type="Submit"  value="Submit" />
</td>
</tr>
</table>

</form>
<?php include_once  "footer.php" ?>