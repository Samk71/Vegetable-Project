<?php include_once  "header.php" ?>
<form action="act_login.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' style="background:aliceblue">
<tr bgcolor='pink'><th colspan='2'>User Login...</th></tr>
<tr>
<th>User Name:</th>
<td><input type="text" name="un"  /></td>
</tr>
<tr>
<th>Password:</th>
<td><input type="password" name="pwd" /></td>
</tr>
<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type="submit"  value="Login" />
</td>
</tr>
</table>
<p class='link'><a href='register.php'>New User</a></p>
</form>
<?php include_once  "footer.php" ?>