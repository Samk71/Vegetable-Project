<?php 
include_once "header.php";  

$rid=$_POST['rid'];

require_once "db_conf.php";

$query="delete from receipts where rid='$rid'";

mysqli_query($con,$query) or die("<h3 style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
	echo "<h3 class='msg'>SUCCESS: Receipt Deleted</h3>";
else
	echo "<h3 class='msg'>Oopsss: Record Not Found</h3>";
	
echo  "<p><a class='link' href='recp_list.php'>Back To List</a></p>";

include_once "footer.php";  
?>