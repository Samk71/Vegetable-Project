<?php 
include_once "header.php";  
?>
<p><a class='link' href='veg_orders_list.php'>Back To List</a></p>
<form action='act_new_veg_ord.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Order</th></tr>
<tr>
<th>SOID</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Veg ord date</th>
<td><input type='date' name='sdate' required /></td>
</tr>
<tr>
<th>User name</th>
<td><input type='text' name='uname' required /></td>
</tr>
<tr>
<th>vid</th>
<td><input type='text' name='vid' required /></td>
</tr>
<tr>
<th>Rate</th>
<td><input type='text' name='rate' required /></td>
</tr>
<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit' value='Order Add' />
</td>
</tr>
</table>
</form>
<?php 
include_once "footer.php";  
?>