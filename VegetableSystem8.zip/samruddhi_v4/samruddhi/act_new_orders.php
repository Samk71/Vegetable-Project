<?php 
include_once "header.php";  

$dt=$_POST['date'];
$sid=$_POST['sid'];
$vid=$_POST['vid'];
$qty=$_POST['qty'];


require_once "db_conf.php";

$query="insert into sup_orders(sdate,vid,qty,sid) values('$dt','$vid','$qty','$sid')";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
{
	echo "<h3 class='msg'>SUCCESS: Order Added</h3>";
	echo  "<p><a class='link' href='sup_orders_list.php'>Back To List</a></p>";
}

include_once "footer.php";  
?>