<?php 
include_once "header.php";  

$sid=$_GET['sid']; // read query string

require_once "db_conf.php";

$query="select * from supplier where sid='$sid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$sname=$row['sname'];
	
}
else
	exit("<h2 class='msg'>Record Not Found</h2>");

?>

<p><a class='link' href='sup_list.php'>Back To List</a></p>
<form action='act_edit_sup.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr><th bgcolor='pink' colspan='2'>Edit Supplier</th></tr>
<tr>
<th>SID:</th>
<td><input type='text' name='sid' value="<?php echo $sid; ?>" readonly /></td>
</tr>
<tr>
<th>Supplier Name:</th>
<td><input type='text' name='sname'  value="<?php echo $sname; ?>"  required /></td>
</tr>

<tr bgcolor='skyblue'>
<td colspan='2' align='center'>
<input type='submit' value='Update Supplier' />
</td>
</tr>
</table>
</form>
<?php
include_once "footer.php";  
?>