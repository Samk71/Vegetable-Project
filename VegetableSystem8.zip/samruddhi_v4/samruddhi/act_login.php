<?php
include_once "header.php";

$un=$_POST['un']; 
$pwd=$_POST['pwd'];

require_once "db_conf.php";

$query="select * from login where uname='$un' and pwd='$pwd'";

$result=mysqli_query($con,$query) or die("Query Error...");

if($row=mysqli_fetch_array($result))
{
	$role=$row['role'];

	$_SESSION['user']=$un;    // save globally
	$_SESSION['role']=$role;

	echo "<h2 class='msg'>Welcome $role $un</h2>";
	echo "<p><a href='$role.php' class='link'>Goto Action Panel</a></p>";
}
else
	echo "<span class='msg' style='color:red'>Invalid Credentials</span>";
?>
<p>
<a href='login.php' class='link'>Try Again</a>
</p>
<?php include_once "footer.php";  ?>
