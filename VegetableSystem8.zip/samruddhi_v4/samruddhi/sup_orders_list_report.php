<?php
$frdt=$_GET['frdt'];
$todt=$_GET['todt'];
?>
<html>
<head>
<title>Supplier  Order Report</title>
</head>
<body>
<center>
<h2>Online MadhuMitra Vegetable Web App</h2>
<a href='#' onclick="print();">Print</a><hr/>
<table border="1" cellpadding="10" cellspacing="0">
<tr bgcolor='silver'><th colspan='10'>Supplier Order Report </th></tr>
<tr bgcolor='lightgrey'><th>SrNo</th><th>SOID</th><th>Supplier</th><th>Sdate</th><th>VID</th><th>QTY</th><th>Vname</th><th>Rate</th><th>Unit</th><th>Location</th></tr>

<?php
require_once"db_conf.php";

$query="select * from v_sup_orders where sdate between '$frdt' and '$todt' order by soid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
    $soid=$row['soid'];
	
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>$soid</td>";
    echo "<td>".$row['sname']."</td>";
	echo "<td>".$row['sdate']."</td>";
	echo "<td>".$row['vid']."</td>";
	echo "<td>".$row['qty']."</td>";
	echo "<td>".$row['vname']."</td>";
	echo "<td>".$row['rate']."</td>";
	echo "<td>".$row['unit']."</td>";
	echo "<td>".$row['location']."</td>";

    echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>