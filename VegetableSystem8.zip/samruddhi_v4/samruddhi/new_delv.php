<?php 
include_once "header.php";  
?>
<p><a class='link' href='delv_list.php'>Back To List</a></p>
<form action='act_new_delv.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Delivery</th></tr>
<tr>
<th>DID</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Delivery Date</th>
<td><input type='date' name='ddt' required /></td>
</tr>
<tr>
<th>OID</th>
<td><input type='text' name='oid' required /></td>
</tr>
<tr>
<th>Notes</th>
<td><input type='text' name='notes' required /></td>
</tr>
<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit' value='Add Delivery' />
</td>
</tr>
</table>
</form>
<?php 
include_once "footer.php";  
?>