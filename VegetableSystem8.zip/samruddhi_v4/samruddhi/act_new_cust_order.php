<?php 
include_once "header.php";  

$odate=$_POST['odate'];
$vid=$_POST['vid'];
$qty=$_POST['qty'];
$rate=0; // $_POST['rate']; 

require_once "db_conf.php";

$query="select rate from veg where vid='$vid'";
$result=mysqli_query($con,$query) or die('Query Error');
if($row=mysqli_fetch_array($result))
{
	$rate=$row['rate'];
}

$query="insert into cust_order(oid,uname,odate,vid,qty,rate) values(null,'$g_user','$odate','$vid','$qty','$rate')";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
{
	echo "<h3 class='msg'>SUCCESS: Customer Order Added</h3>";
	echo  "<p><a class='link' href='cust_order_list.php'>Back To List</a></p>";
}

include_once "footer.php";  
?>