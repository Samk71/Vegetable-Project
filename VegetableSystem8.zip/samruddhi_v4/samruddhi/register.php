<?php include_once  "header.php" ?>
<form action="act_register.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' bgcolor='aliceblue'>
<tr bgcolor='skyblue'><th colspan='2'>Registration...</th></tr>
<tr>
<th>User Name:</th>
<td><input type="text" name="un" required  /></td>
</tr>
<tr>
<th>Password:</th>
<td><input type="password" name="npwd"  required /></td>
</tr>
<tr>
<th>Confirm Password:</th>
<td><input type="password" name="cpwd"  required /></td>
</tr>
<tr bgcolor='skyblue'>
<td colspan='2' align='center'>
<input type="submit"  value="Submit" />
</td>
</tr>
</table>
</form>
<p class='link'><a href='login.php'>Cancel</a></p>
<?php include_once  "footer.php" ?>