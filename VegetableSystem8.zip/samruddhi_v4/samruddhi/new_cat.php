<?php 
include_once "header.php";  
?>
<p><a class='link' href='cat_list.php'>Back To List</a></p>
<form action='act_new_cat.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Category</th></tr>
<tr>
<th>CID</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Category</th>
<td><input type='text' name='cname' required /></td>
</tr>
<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit' value='Add Category' />
</td>
</tr>
</table>
</form>
<?php 
include_once "footer.php";  
?>