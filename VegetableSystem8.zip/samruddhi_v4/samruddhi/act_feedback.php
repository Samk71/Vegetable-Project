<?php include_once  "header.php";

$fullname=$_POST['fullname'];
$fodt=date('Y-m-d');
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$feedback=$_POST['feedback'];


    echo "<p class='link'><a href='feedback.php'>Back</a></p>";

    require_once "db_conf.php";
    $query="insert into feedback(fid,fullname,fodt,mobile,email,feedback) values(null,'$fullname','$fodt','$mobile','$email','$feedback')";

    mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");
    
    if(mysqli_affected_rows($con)>0)
    
        echo "<h3 class='msg' style='color:green'>SUCCESS: Feedback Added</h3>";
    else
        echo"<p class='msg' style='color:red'></p>";
      
  ?>  
  <p>
    <a href='feedback.php' class='link'>Try Again</a>
</p>


<?include_once  "footer.php";?>