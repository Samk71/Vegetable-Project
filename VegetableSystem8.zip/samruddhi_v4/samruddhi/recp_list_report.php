<!--<?php 
include_once "header.php";  
?>-->
<center>
<h3>Online MadhuMitra Vegetables Web App</h3>
<a href='#' onclick="print();">print</a><hr/>
<table border="1" cellpadding="15" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='silver'><th colspan='8'>Receipts List</th></tr>
<tr bgcolor='lightgrey'><th>SrNo</th><th>Receipt id</th><th>Receipt Date</th><th>Uname</th><th>Amount</th><th>Notes</th></tr>

<?php
require_once"db_conf.php"; 

$query="select * from receipts  order by rid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
	$rid=$row['rid'];
    echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td align='center'>$rid</td>";
    echo "<td>".$row['rdate']."</td>";
	echo "<td>".$row['uname']."</td>";
	echo "<td>".$row['amt']."</td>";
	echo "<td>".$row['notes']."</td>";
	#echo "<td>";
           
	
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>