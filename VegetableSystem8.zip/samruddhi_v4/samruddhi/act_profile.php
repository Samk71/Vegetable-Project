<?php include_once  "header.php";

    $fn=$_POST['fn'];
    $loc=$_POST['loc'];
    $adr=$_POST['adr'];
    $ci=$_POST['ci'];
    $email=$_POST['email'];

    echo "<p class='link'><a href='member.php'>Back</a></p>";

    require_once "db_conf.php";

    $query="update profile set fn='$fn',loc='$loc',adr='$adr',ci='$ci',email='$email' where uname='$g_user'";
echo $query;
    mysqli_query($con,$query) or die("<span class='msg' style='color:red'><Error: ".mysqli_error($con)."</span>");

    if(mysqli_affected_rows($con) > 0)
           echo "<h2 class='msg' style='color:green'>Success: Profile Updated</h2>";
    else
    echo "<p class='msg' style='color:red'>Opss: Profile Nothing Updated</p>";
include_once  "footer.php";
?>