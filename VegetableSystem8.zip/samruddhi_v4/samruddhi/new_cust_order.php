<?php 
include_once "header.php";  
require_once "db_conf.php";

$query="select vid,vname from veg order by vname";
$result=mysqli_query($con,$query) or die('Query Error');

?>
<p><a class='link' href='cust_order_list.php'>Back To List</a></p>
<form action='act_new_cust_order.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Customer Order</th></tr>
<tr>
<th>Order ID</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Order Date</th>
<td><input type='date' name='odate' required /></td>
</tr>
<th>Vegetable:</th>
<td> 
<select name="vid" style='width:100px' >
<?php
while($row=mysqli_fetch_array($result))
{
	$vid=$row['vid'];
	$vn=$row['vname'];
    echo "<option value='$vid'>$vn</option>";
}
?>
</select>
</td>
</tr>
<th>Quantity</th>
<td><input type='text' name='qty' required /></td>
</tr>


<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit' value='Add Order' />
</td>
</tr>
</table>
</form>
<?php 
include_once "footer.php";  
?>