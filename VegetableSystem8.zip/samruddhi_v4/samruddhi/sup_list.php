<?php 
include_once "header.php";  
?>
<p>

<a class='link' href='new_sup.php'>New Supplier</a>
</p>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='khaki'><th colspan='6'>Supplier List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>Supplier Name</th><th>Location</th><th>Address</th><th>Cont_Info</th><th>Action</th></tr>

<?php
require_once"db_conf.php";

$query="select * from supplier order by sid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
 	$sid=$row['sid'];
	$sname=$row['sname'];
    $loc=$row['location'];
    $add=$row['address'];
	$ci=$row['cont_info'];

	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['sname']."</td>";
	echo "<td>".$row['location']."</td>";
	echo "<td>".$row['address']."</td>";
	echo "<td>".$row['cont_info']."</td>";
               echo "<td><a href='edit_sup.php?sid=$sid'>Edit</a> <a href='del_sup.php?sid=$sid'>Delete</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>