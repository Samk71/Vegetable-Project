<?php 
include_once "header.php";  
?>
<p>

<a class='link' href='new_veg.php'>New Veg</a>
</p>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='khaki'><th colspan='5'>Vegetables List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>Veg Name</th><th>Unit</th><th>Rate</th><th>Action</th></tr>

<?php
require_once"db_conf.php";

$query="select * from veg order by vid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
 	$vid=$row['vid'];
	$vname=$row['vname'];
	$unit=$row['unit'];
	$rate=$row['vid'];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['vname']."</td>";
	echo "<td>".$row['unit']."</td>";
	echo "<td>".$row['rate']."</td>";
	
               echo "<td><a href='edit_veg.php?vid=$vid'>Edit</a> <a href='del_veg.php?vid=$vid'>Delete</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>