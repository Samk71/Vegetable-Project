<?php 
include_once "header.php";  
?>
<p>

<a class='link' href='new_sup_orders.php'>New Order</a>
</p>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='khaki'><th colspan='7'>Supplier Order List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>OID</th><th>Date</th><th>Vegetable</th><th>Qty</th><th>Supplier</th><th>Action</th></tr>

<?php
require_once"db_conf.php";

$query="select * from v_sup_orders order by soid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
    $soid=$row['soid'];
	
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>$soid</td>";
	echo "<td>".$row['sdate']."</td>";
	echo "<td>".$row['vname']."</td>";
	echo "<td>".$row['qty']."</td>";
    echo "<td>".$row['sname']."</td>";
    echo "<td><a href='edit_sup.php?soid=$soid'>Edit</a> <a href='del_sup.php?soid=$soid'>Delete</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>