<?php 
include_once "header.php";  

$did=$_GET['did'];    // read query string

require_once "db_conf.php";

$query="select * from delivery where did='$did'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$oid=$row['oid'];
}
else
	exit("<h2>Record Not Found</h2>");

?>

<h2 class='msg' style='color:red'>Delete Delivery: <?php echo $oid; ?></h2>

<p><a class='link' href='delv_list.php'>Back To List</a></p>
<form action='act_del_delv.php' method='post'>

<input type='hidden' name='did' value="<?php echo $did; ?>" /></td>
<h3 class='msg'>Are You Sure?</h3>
<input type='submit' value='Confirm Delete' />

</form>
<?php 
include_once "footer.php";  
?>