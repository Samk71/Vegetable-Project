<?php 
include_once "header.php";  
?>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='khaki'><th colspan='7'>Member Profile List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>FullName</th><th>Location</th><th>Address</th><th>Cont_Info</th><th>email</th></tr>

<?php
require_once"db_conf.php";

$query="select * from profile order by fn desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
 	
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['fn']."</td>";
    echo "<td>".$row['loc']."</td>";
	echo "<td>".$row['adr']."</td>";
	echo "<td>".$row['ci']."</td>";
	echo "<td>".$row['email']."</td>";
	#echo "<td><a href='del_sup.php?fn=$fn'>Delete</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>