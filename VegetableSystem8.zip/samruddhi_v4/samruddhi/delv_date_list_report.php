<?php
$frdt=$_GET['frdt'];
$todt=$_GET['todt'];
?>
<html>
<head>
<title>Delivery Report</title>
</head>
<body>
<center>
<h2>Online MadhuMitra Vegetable Web App</h2>	
<a href='#' onclick="print();">Print</a><hr/>
<table border="1" cellpadding="15" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='silver'><th colspan='9'>Delivery List</th></tr>
<tr bgcolor='lightgrey'><th>SrNo</th><th>Delivery id</th><th>Uname</th><th>Delivery Date</th><th>OID</th><th>Notes</th></tr>

<?php
require_once"db_conf.php";

$query="select * from delivery where ddt between '$frdt' and '$todt' order by did desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
	$did=$row['did'];
    	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td align='center'>$did</td>";
	echo "<td>".$row['uname']."</td>";
	echo "<td>".$row['ddt']."</td>";
	echo "<td>".$row['oid']."</td>";
	echo "<td>".$row['notes']."</td>";
  
           
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>