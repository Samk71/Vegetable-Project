<?php 
$con=@mysqli_connect("localhost","root","","veg_db");

if(!$con)
 	exit("Database connection Error:".mysqli_connect_error());
?>