-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 04, 2024 at 08:27 AM
-- Server version: 10.1.38-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `veg_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cid` int(5) NOT NULL,
  `cname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `cname`) VALUES
(2, 'Biscuit'),
(3, 'Chocolate'),
(4, 'Drinks'),
(10, 'potato'),
(1, 'Snacks'),
(6, 'Soap'),
(11, 'Tomato');

-- --------------------------------------------------------

--
-- Table structure for table `cust_order`
--

CREATE TABLE `cust_order` (
  `oid` int(5) NOT NULL,
  `uname` varchar(50) NOT NULL,
  `odate` date NOT NULL,
  `vid` int(50) NOT NULL,
  `qty` int(100) NOT NULL,
  `rate` int(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cust_order`
--

INSERT INTO `cust_order` (`oid`, `uname`, `odate`, `vid`, `qty`, `rate`) VALUES
(1, 'sk', '2024-06-01', 1, 1, 10),
(52, 'sk', '2024-06-28', 2, 11, 20);

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `uname` varchar(25) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `role` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uname`, `pwd`, `role`) VALUES
('ad', 'ad', 'admin'),
('sk', 'sk', 'member');

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `uname` varchar(20) NOT NULL,
  `fn` varchar(50) DEFAULT NULL,
  `loc` varchar(20) DEFAULT NULL,
  `adr` varchar(20) DEFAULT NULL,
  `ci` varchar(100) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`uname`, `fn`, `loc`, `adr`, `ci`, `email`) VALUES
('sk', 'Samruddhi Kamble', 'Yelavi', 'Station Road', '9890100100', 'sam@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `sid` int(10) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `cont_info` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sid`, `sname`, `location`, `address`, `cont_info`) VALUES
(1, ' swati patil', 'tasgaon', 'tasgaon', 'tasgaon'),
(2, 'Samruddhi', 'tasgaon', 'tasgaon', 'tasgaon'),
(5, 'Prachi', 'pune', 'sangli', '9970758760'),
(26, 'pooja', 'pune', 'sangli', '9970758760'),
(27, 'ram', 'sangli', 'sangli', '1234565432'),
(28, 'sham', 'mane', 'tasgaon', '9970758760');

-- --------------------------------------------------------

--
-- Table structure for table `sup_orders`
--

CREATE TABLE `sup_orders` (
  `soid` int(50) NOT NULL,
  `sdate` date NOT NULL,
  `vid` int(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `sid` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sup_orders`
--

INSERT INTO `sup_orders` (`soid`, `sdate`, `vid`, `qty`, `sid`) VALUES
(1, '2024-06-27', 1, '10', 1),
(2, '2024-06-27', 2, '10', 1),
(3, '2024-07-02', 3, '5', 5);

-- --------------------------------------------------------

--
-- Table structure for table `veg`
--

CREATE TABLE `veg` (
  `vid` int(5) NOT NULL,
  `vname` varchar(50) NOT NULL,
  `unit` varchar(15) NOT NULL,
  `rate` int(150) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `veg`
--

INSERT INTO `veg` (`vid`, `vname`, `unit`, `rate`) VALUES
(1, 'Cabbage', 'KG', 50),
(2, 'Tomato', 'KG', 10),
(3, 'Onion', 'KG', 50),
(7, 'Coconut', 'Nos', 20),
(8, 'Dudhi Bhopala', 'Nos', 25),
(10, 'Methi', 'KG', 30),
(11, 'Green peas', 'KG', 40);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_cust_order`
-- (See below for the actual view)
--
CREATE TABLE `v_cust_order` (
`oid` int(5)
,`uname` varchar(50)
,`odate` date
,`vid` int(50)
,`qty` int(100)
,`rate` int(150)
,`vname` varchar(50)
,`unit` varchar(15)
,`fn` varchar(50)
,`loc` varchar(20)
,`ci` varchar(100)
);

-- --------------------------------------------------------

--
-- Stand-in structure for view `v_sup_orders`
-- (See below for the actual view)
--
CREATE TABLE `v_sup_orders` (
`soid` int(50)
,`sdate` date
,`vid` int(50)
,`qty` varchar(50)
,`sid` int(20)
,`vname` varchar(50)
,`rate` int(150)
,`unit` varchar(15)
,`sname` varchar(50)
,`location` varchar(50)
);

-- --------------------------------------------------------

--
-- Structure for view `v_cust_order`
--
DROP TABLE IF EXISTS `v_cust_order`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_cust_order`  AS  select `co`.`oid` AS `oid`,`co`.`uname` AS `uname`,`co`.`odate` AS `odate`,`co`.`vid` AS `vid`,`co`.`qty` AS `qty`,`co`.`rate` AS `rate`,`v`.`vname` AS `vname`,`v`.`unit` AS `unit`,`p`.`fn` AS `fn`,`p`.`loc` AS `loc`,`p`.`ci` AS `ci` from ((`cust_order` `co` join `veg` `v`) join `profile` `p` on(((`co`.`vid` = `v`.`vid`) and (`p`.`uname` = `co`.`uname`)))) ;

-- --------------------------------------------------------

--
-- Structure for view `v_sup_orders`
--
DROP TABLE IF EXISTS `v_sup_orders`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `v_sup_orders`  AS  select `so`.`soid` AS `soid`,`so`.`sdate` AS `sdate`,`so`.`vid` AS `vid`,`so`.`qty` AS `qty`,`so`.`sid` AS `sid`,`v`.`vname` AS `vname`,`v`.`rate` AS `rate`,`v`.`unit` AS `unit`,`s`.`sname` AS `sname`,`s`.`location` AS `location` from ((`sup_orders` `so` join `supplier` `s`) join `veg` `v` on(((`so`.`sid` = `s`.`sid`) and (`so`.`vid` = `v`.`vid`)))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cust_order`
--
ALTER TABLE `cust_order`
  ADD PRIMARY KEY (`oid`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `sup_orders`
--
ALTER TABLE `sup_orders`
  ADD PRIMARY KEY (`soid`);

--
-- Indexes for table `veg`
--
ALTER TABLE `veg`
  ADD PRIMARY KEY (`vid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cust_order`
--
ALTER TABLE `cust_order`
  MODIFY `oid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `sup_orders`
--
ALTER TABLE `sup_orders`
  MODIFY `soid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `veg`
--
ALTER TABLE `veg`
  MODIFY `vid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
