<?php include_once  "header.php"; 
require_once "db_conf.php";
$query="select * from cust_order profile where uname='$g_user'";
$result=mysqli_query($con,$query);
$result=mysqli_query($con,$query) or die("Query Error");
if($row=mysqli_fetch_array($result))
{
    $oid=$row['oid'];
    $uname=$row['uname'];
    $odate=$row['odate'];
    $vid=$row['vid'];
    $qty=$row['qty'];
    $rate=$row['rate'];
}
else
        exit("<h2 class='msg'>Customer Order Not Found</h2>");    
?>
<form action="act_cust_order.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' bgcolor='aliceblue'>
<tr bgcolor='skyblue'><th colspan='2'> cust_order Profile...</th></tr>
<th>Enter Order id:</th>
<td><input type="text" name="oid" value="<?php echo $oid; ?>"/></td>
</tr>
<th>Enter Username:</th>
<td><input type="text" name="uname" value="<?php echo $uname; ?>"/></td>
</tr>
<th>Enter Order Date:</th>
<td><input type="date" name="odate" value="<?php echo $odate; ?>"/></td>
</tr>
<th>Enter Vegetable id:</th>
<td><input type="text" name="vid" value="<?php echo $vid; ?>"/></td>
</tr>
<th> Enter Quantity:</th>
<td><input type="text" name="qty" value="<?php echo $qty; ?>"/></td>
</tr>
<th>Enter Rate:</th>
<td><input type="text" name="rate" value="<?php echo $rate; ?>"/></td>
</tr>
<tr bgcolor='skyblue'>
<td colspan='2' align='center'>
<input type="submit"  value="Update Customer Order Profile" />
</td>
</tr>
</table>
</form>
<?php include_once  "footer.php" ?>