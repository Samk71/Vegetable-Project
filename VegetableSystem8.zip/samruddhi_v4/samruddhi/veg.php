<?php include_once  "header.php"; 
require_once "db_conf.php";
$query="select * from  veg profile where vname='$g_user'";
$result=mysqli_query($con,$query);
$result=mysqli_query($con,$query) or die("Query Error");
if($row=mysqli_fetch_array($result))
{
    $vid=$row['vid'];
    $vname=$row['vname'];
    $unit=$row['unit'];
    $rate=$row['rate'];
}
else
        exit("<h2 class='msg'>Veg Not Found</h2>");    
?>
<form action="act_veg.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' bgcolor='aliceblue'>
<tr bgcolor='skyblue'><th colspan='2'> Veg Profile...</th></tr>
<th>Enter Vegetable id:</th>
<td><input type="text" name="vid" value="<?php echo $vid; ?>"/></td>
</tr>
<th> Enter Vegetable Name:</th>
<td><input type="text" name="vname" value="<?php echo $vname; ?>"/></td>
</tr>

<th>Unit:</th>
<td>
<select name="unit" style='width:100px'>
<option value="kg">KG</option>
<option value="Gram">Gram</option>
<option value="num">Number</option>
</select>
</td>
</tr>
<th>Enter Rate:</th>
<td><input type="text" name="rate" value="<?php echo $rate; ?>"/></td>
</tr>
<tr bgcolor='skyblue'>
<td colspan='2' align='center'>
<input type="submit"  value="Update  Veg Profile" />
</td>
</tr>
</table>
</form>
<?php include_once  "footer.php" ?>