<?php 
include_once "header.php";  
?>
<p><a class='link' href='recp_list.php'>Back To List</a></p>
<form action='act_new_recp.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Receipt</th></tr>
<tr>
<th>RID</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Receipt Date</th>
<td><input type='date' name='rdate' required /></td>
</tr>
<tr>
<th>Uname</th>
<td> 
<select name="uname" style='width:100px' >
<option>Nemika Kamble</option>
</select></td>
</tr>
<tr>
<th>Amount</th>
<td><input type='text' name='amt' required /></td>
</tr>
<tr>
<th>Notes</th>
<td><input type='text' name='notes' required /></td>
</tr>
<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit' value='Add Receipt' />
</td>
</tr>
</table>
</form>
<?php 
include_once "footer.php";  
?>