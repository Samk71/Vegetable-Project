<?php 
include_once "header.php";  

$cname=$_POST['cname'];

require_once "db_conf.php";

$query="insert into category(cid,cname) values(null,'$cname')";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
{
	echo "<h3 class='msg'>SUCCESS: Category Added</h3>";
	echo  "<p><a class='link' href='cat_list.php'>Back To List</a></p>";
}

include_once "footer.php";  
?>