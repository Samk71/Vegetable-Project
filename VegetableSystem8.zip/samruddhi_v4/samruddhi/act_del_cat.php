<?php 
include_once "header.php";  

$cid=$_POST['cid'];

require_once "db_conf.php";

$query="delete from category where cid='$cid'";

mysqli_query($con,$query) or die("<h3 style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
	echo "<h3 class='msg'>SUCCESS: Category Deleted</h3>";
else
	echo "<h3 class='msg'>Oopsss: Record Not Found</h3>";
	
echo  "<p><a class='link' href='cat_list.php'>Back To List</a></p>";

include_once "footer.php";  
?>