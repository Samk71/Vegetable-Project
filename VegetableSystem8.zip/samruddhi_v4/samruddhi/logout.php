<html>
<head>
<link rel="stylesheet" href='mystyle.css' />
<title>Online MadhuMitra Vegetables Web App</title>
</head>
<body>
<center>
<h1> Online MadhuMitra Vegetables Web App</h1>

<?php
	session_start();
	unset($_SESSION['user']);
	unset($_SESSION['role']);

	session_destroy();
?>
<h2 class="msg">You Have Been logged Out</h2>
<p><a href='index.php' class='link'>Back Home</a></p>
</div>
</center>
</body>
</html>