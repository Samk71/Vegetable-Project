<?php include_once  "header.php";

$un=$_POST['un'];
$npwd=$_POST['npwd'];
$cpwd=$_POST['cpwd'];

echo "<p class='link'><a href='register.php'>Try Again</a></p>";

if($npwd!=$cpwd)
{
	exit ("<h2 class='msg' style='color:red'>Error: Passwords Mismatch</h2>");
}
require_once "db_conf.php";

$query="insert into login(uname,pwd,role) values('$un','$npwd','member')";

mysqli_query($con,$query) or die("<span class='msg' style='color:red'>Error: ".mysqli_error($con)."</span>");

if(mysqli_affected_rows($con) > 0)
{
	$query="insert into profile(uname) values('$un')";
	mysqli_query($con,$query) or die("<span class='msg' style='color:red'>Error: ".mysqli_error($con)."</span>");

	echo "<h2 class='msg' style='color:green'>Success: New User Added</h2>";
}

else
	echo "<p class='msg' style='color:red'>Error: Cannot Add User</p>";

include_once  "footer.php";?>