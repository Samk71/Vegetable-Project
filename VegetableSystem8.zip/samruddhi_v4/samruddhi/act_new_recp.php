<?php 
include_once "header.php";  

$rdate=$_POST['rdate'];
$uname=$_POST['uname'];
$amt=$_POST['amt'];
$notes=$_POST['notes'];

require_once "db_conf.php";

$query="insert into receipts (rid,rdate,uname,amt,notes) values(null,'$rdate','$uname','$amt','$notes')";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
{
	echo "<h3 class='msg'>SUCCESS: Receipt Added</h3>";
	echo  "<p><a class='link' href='recp_list.php'>Back To List</a></p>";
}
include_once "footer.php";  
?>