<?php 
include_once "header.php";  

$vid=$_GET['vid'];    // read query string

require_once "db_conf.php";

$query="select * from veg where vid='$vid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$vname=$row['vname'];
}
else
	exit("<h2 class='msg'>Record Not Found</h2>");

?>

<p><a class='link' href='veg_list.php'>Back To List</a></p>
<form action='act_edit_veg.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr><th bgcolor='pink' colspan='2'>Edit veg</th></tr>
<tr>
<th>VID</th>
<td><input type='text' name='vid' value="<?php echo $vid; ?>" readonly /></td>
</tr>
<tr>
<th>Veg</th>
<td><input type='text' name='vname'  value="<?php echo $vname; ?>"  required /></td>
</tr>
<tr bgcolor='skyblue'>
<td colspan='2' align='center'>
<input type='submit' value='Update veg' />
</td>
</tr>
</table>
</form>
<?php
include_once "footer.php";  
?>