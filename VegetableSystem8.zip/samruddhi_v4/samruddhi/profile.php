<?php include_once  "header.php";

require_once "db_conf.php";

$query="select * from profile where uname='$g_user'";

$result=mysqli_query($con,$query) or die("Query Error...");

if($row=mysqli_fetch_array($result))
{
	$fn=$row['fn'];
    $loc=$row['loc'];
    $adr=$row['adr'];
    $ci=$row['ci'];
    $email=$row['email'];
}
else
     exit("<h2 class='msg'>Profile Not Found</h2>");
?>
	
<form action="act_profile.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' bgcolor='aliceblue'>
<tr bgcolor='skyblue'><th colspan='2'> Member Profile</th></tr>
<tr>
<th>Full Name:</th>
<td><input type="text"  name="fn" value="<?php echo $fn; ?>" /></td>
</tr>
<th>Location:</th>
<td><input type="text"  name="loc"  value="<?php echo $loc; ?>"/></td>
</tr>
<tr>
<th>Address:</th>
<td>
<textarea name="adr" rows="3" cols="21"><?php echo $adr; ?></textarea>
</td>
</tr>
<tr>
<th>ContactInfo:</th>
<td><input type="text"  name="ci" value="<?php echo $ci; ?>" /></td>
</tr>
<tr>
<th>Email:</th>
<td><input type="email"  name="email" value="<?php echo $email; ?>"/></td>
</tr>

<tr bgcolor='skyblue'>
<td colspan='2' align='center'> 
<input type="submit"  value="Update Profile" />
</td>
</tr>
</table>
</form>

<?php include_once  "footer.php" ?>



