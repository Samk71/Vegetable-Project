<?php 
include_once "header.php";  
?>
<p>

<a class='link' href='new_veg_orders.php'>New Order</a>
</p>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='khaki'><th colspan='7'>Order List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>Date</th><th>Vegetable</th><th>Quantity</th><th>Rate</th><th>Payment</th><th>Action</th></tr>

<?php
require_once"db_conf.php";

$query="select * from v_veg_order where uname='$g_user' and payment<>'Confirm' order by soid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
 	$soid=$row['soid'];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['odate']."</td>";
	echo "<td>".$row['vame']."</td>";
	echo "<td>".$row['qty']."</td>";
	echo "<td>".$row['rate']."</td>";
	echo "<td>".$row['payment']."</td>";           
	echo "<td>";
	echo "<a href='pay_veg_orders.php?soid=$soid'>Pay</a>";
	echo "&nbsp;&nbsp;<a href='del_veg_orders.php?soid=$soid'>Delete</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>