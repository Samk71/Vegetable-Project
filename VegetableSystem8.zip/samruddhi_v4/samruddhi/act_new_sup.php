<?php 
include_once "header.php";  

$sname=$_POST['sname'];
$loc=$_POST['loc'];
$add=$_POST['add'];
$ci=$_POST['ci'];

require_once "db_conf.php";

$query="insert into supplier(sid,sname,location,address,cont_info) values(null,'$sname','$loc','$add','$ci')";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
{
	echo "<h3 class='msg'>SUCCESS: Supplier Added</h3>";
	echo  "<p><a class='link' href='sup_list.php'>Back To List</a></p>";
}

include_once "footer.php";  
?>