<?php 
include_once "header.php";  


$ddt=$_POST['ddt'];
$oid=$_POST['oid'];
$notes=$_POST['notes'];

require_once "db_conf.php";

$query="insert into delivery (did,ddt,oid,notes) values(null,'$ddt','$oid','$notes')";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
{
	echo "<h3 class='msg'>SUCCESS: Delivery Added</h3>";
	echo  "<p><a class='link' href='delv_list.php'>Back To List</a></p>";
}

include_once "footer.php";  
?>