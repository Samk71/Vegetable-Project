<?php include_once  "header.php";

if($g_role!='admin')
{
	exit("<h2 class='msg' style='color:red'>Access Denied. Please Login</h2>");
}
 ?>
<div class='msg'>
<h2>Welcome To Admin Reports</h2>
<ol style='text-align:left'>
<li><p>To View Customer Report <a href='profile_list_report.php'>Click Here</a></p></li>
<li>
<form action='cust_order_list_report.php'>
<p>
<fieldset >
<legend>Customer Order Report: From And To Dates</legend><p> 
<input type="date"  name="frdt" value="<?php echo date('Y-m-d'); ?>"/> 
<input type="date"  name="todt" value="<?php echo date('Y-m-d');?>"  /> 
</p>
<input type="submit" value="Show Report"/>
</p>
</fieldset>
</form>

</li>
</ol>
</div>
<?php include_once  "footer.php" ?>