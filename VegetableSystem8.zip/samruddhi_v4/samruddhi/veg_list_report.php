<!--<?php 
include_once "header.php";  
?>-->
<center>
<h2>Online MadhuMitra Vegetable Web App</h2>
<a href='#' onclick="print();">print</a><hr/>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='silver'><th colspan='5'>Veg List</th></tr>
<tr bgcolor='lightgrey'><th>SrNo</th><th>Veg Name</th><th>Unit</th><th>Rate</th></tr>

<?php
require_once"db_conf.php";

$query="select * from veg order by vid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
 	$vid=$row['vid'];
	$vname=$row['vname'];
	$unit=$row['unit'];
	$rate=$row['vid'];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['vname']."</td>";
	echo "<td>".$row['unit']."</td>";
	echo "<td>".$row['rate']."</td>";
	
              
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>