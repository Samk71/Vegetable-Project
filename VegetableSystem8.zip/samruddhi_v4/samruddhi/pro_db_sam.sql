-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 28, 2024 at 09:04 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pro_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cid` int(5) NOT NULL,
  `cname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cid`, `cname`) VALUES
(2, 'Biscuit'),
(3, 'Chocolate'),
(4, 'Drinks'),
(10, 'potato'),
(1, 'Snacks'),
(6, 'Soap'),
(11, 'Tomato');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `uname` varchar(25) NOT NULL,
  `pwd` varchar(15) NOT NULL,
  `role` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`uname`, `pwd`, `role`) VALUES
('ad', 'ad', 'admin'),
('samruddhi', 'sk', 'member');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pid` int(5) NOT NULL,
  `pname` varchar(50) NOT NULL,
  `rate` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pid`, `pname`, `rate`) VALUES
(1, 'Onion', 10),
(2, 'potato', 30);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `uname` varchar(20) NOT NULL,
  `fn` varchar(50) DEFAULT NULL,
  `loc` varchar(20) DEFAULT NULL,
  `add` varchar(20) DEFAULT NULL,
  `ci` varchar(100) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`uname`, `fn`, `loc`, `add`, `ci`, `email`) VALUES
('pk', NULL, NULL, NULL, NULL, NULL),
('pp', 'prachi', 'tasgaon', 'tasgaon', 'tasgaon', 'abc@gmail.com'),
('samruddhi', '', '', '', '', 'sam@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE `supplier` (
  `sid` int(10) NOT NULL,
  `sname` varchar(50) NOT NULL,
  `location` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `cont_info` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`sid`, `sname`, `location`, `address`, `cont_info`) VALUES
(1, ' swati patil', 'tasgaon', 'tasgaon', 'tasgaon'),
(2, 'Samruddhi', 'tasgaon', 'tasgaon', 'tasgaon'),
(5, 'Prachi', 'pune', 'sangli', '9970758760'),
(26, 'pooja', 'pune', 'sangli', '9970758760'),
(27, 'ram', 'sangli', 'sangli', '1234565432'),
(28, 'sham', 'mane', 'tasgaon', '9970758760');

-- --------------------------------------------------------

--
-- Table structure for table `sup_orders`
--

CREATE TABLE `sup_orders` (
  `soid` int(50) NOT NULL,
  `sdate` date NOT NULL,
  `sname` varchar(50) NOT NULL,
  `vname` varchar(50) NOT NULL,
  `vid` int(50) NOT NULL,
  `qty` varchar(50) NOT NULL,
  `sid` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sup_orders`
--

INSERT INTO `sup_orders` (`soid`, `sdate`, `sname`, `vname`, `vid`, `qty`, `sid`) VALUES
(1, '2024-06-27', '', '', 0, '10', 1),
(2, '2024-06-27', '', '', 0, '10', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cid`),
  ADD UNIQUE KEY `cname` (`cname`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`uname`);

--
-- Indexes for table `supplier`
--
ALTER TABLE `supplier`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `sup_orders`
--
ALTER TABLE `sup_orders`
  ADD PRIMARY KEY (`soid`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `cid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pid` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `supplier`
--
ALTER TABLE `supplier`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `sup_orders`
--
ALTER TABLE `sup_orders`
  MODIFY `soid` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
