<?php 
include_once "header.php";  

$cid=$_POST['cid'];
$cname=$_POST['cname'];

require_once "db_conf.php";

$query="update category set cname='$cname' where cid='$cid'";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
	echo "<h3 class='msg'>SUCCESS: Category Updated</h3>";
else
	echo "<h3 class='msg'>Oopsss: Nothing To Update</h3>";
	
echo  "<p><a class='link' href='cat_list.php'>Back To List</a></p>";

include_once "footer.php";  
?>