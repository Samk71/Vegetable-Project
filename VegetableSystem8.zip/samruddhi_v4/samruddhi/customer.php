<?php include_once  "header.php" ?>

<form action="act_ass1.php" method="get">
<table border='1' cellpadding='7' cellspacing='0' bgcolor='aliceblue'>
<tr bgcolor='skyblue'><th colspan='2'>Customer</th></tr>

<tr>
<th>Customer Id:</th>
<td><input type="text"  name="id"  /></td>
</tr>
<tr>
<th>Customer Name:</th>
<td><input type="text"  name="nm"  /></td>
</tr>
<tr>
<th>Email:</th>
<td><input type="text"  name="email"  /></td>
</tr>
<tr>
<th>Contact:</th>
<td><input type="text"  name="cont"  /></td>
</tr>
<tr><th>Address:</th>
<td>
<textarea name="dtls" rows="3" cols="21"></textarea>
</td>
</tr>
<tr bgcolor='skyblue'>
<td colspan='2' align='center'> 
<input type="submit"  value="Submit" />
</td>
</tr>
</table>
</form>

<?php include_once  "footer.php" ?>
