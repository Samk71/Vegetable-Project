<?php 
include_once "header.php";  

$oid=$_GET['oid'];    // read query string

require_once "db_conf.php";

$query="select * from cust_order where oid='$oid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$uname=$row['uname'];
}
else
	exit("<h2>Record Not Found</h2>");

?>

<h2 class='msg' style='color:red'>Delete Customer Order: <?php echo $uname; ?></h2>

<p><a class='link' href='cust_order_list.php'>Back To List</a></p>
<form action='act_del_cust_order.php' method='post'>

<input type='hidden' name='oid' value="<?php echo $oid; ?>" /></td>
<h3 class='msg'>Are You Sure?</h3>
<input type='submit' value='Confirm Delete' />

</form>
<?php 
include_once "footer.php";  
?>