<?php 
include_once "header.php";  

$oid=$_GET['oid'];    // read query string

require_once "db_conf.php";

$query="select * from cust_order where oid='$oid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$uname=$row['uname'];
}
else
	exit("<h2 class='msg'>Record Not Found</h2>");

?>

<p><a class='link' href='cust_order_list.php'>Back To List</a></p>
<form action='act_edit_cust_order.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr><th bgcolor='pink' colspan='2'>Edit Customer Order</th></tr>
<tr>
<th>Order ID</th>
<td><input type='text' name='oid' value="<?php echo $oid; ?>" readonly /></td>
</tr>
<tr>
<th>Customer Order</th>
<td><input type='text' name='uname'  value="<?php echo $uname; ?>"  required /></td>
</tr>
<tr bgcolor='skyblue'>
<td colspan='2' align='center'>
<input type='submit' value='Update Order' />
</td>
</tr>
</table>
</form>
<?php
include_once "footer.php";  
?>