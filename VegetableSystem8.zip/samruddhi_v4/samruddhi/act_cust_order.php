<?php include_once  "header.php";

 $oid=$row['oid'];
 $uname=$row['uname'];
 $odate=$row['odate'];
 $vid=$row['vid'];
 $qty=$row['qty'];
 $rate=$row['rate'];

echo "<p class='link'><a href='cust_order.php'>Back</a></p>";

require_once "db_conf.php";

$query="update cust_order profile set uname='$uname',odate='$odate',vid='$vid',qty='$qty',rate='$rate' where uname='$g_user'";

mysqli_query($con,$query) or die("<span class='msg' style='color:red'>Error: ".mysqli_error($con)."</span>");

if(mysqli_affected_rows($con) > 0) 
	echo "<h2 class='msg' style='color:green'>Success: Customer Order Updated</h2>";
else
	echo "<p class='msg' style='color:red'>Oopss:Nothing Updated</p>";

include_once  "footer.php";?>