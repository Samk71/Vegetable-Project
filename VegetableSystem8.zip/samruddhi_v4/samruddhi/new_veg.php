<?php 
include_once "header.php";  
?>
<p><a class='link' href='veg_list.php'>Back To List</a></p>
<form action='act_new_veg.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Vegetable</th></tr>
<tr>
<th>VID</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Veg</th>
<td><input type='text' name='vname' required /></td>
</tr>
<tr>
<th>Unit:</th>
<td>
<select name="unit">
<option value="kg">KG</option>
<option value="Gram">Gram</option>
<option value="num">Number</option>
</select>
</td>
</tr>
<tr>
<th>Rate</th>
<td><input type='text' name='rate' required /></td>
</tr>

<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit'  value='Add vegetable' />
</td>
</tr>
</table>
</form>
<?php 
include_once "footer.php";  
?>