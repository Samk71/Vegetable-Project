<?php include_once  "header.php";

require_once "db_conf.php";

$query="select * from supplier where sname='$g_user'";


$result = mysqli_query($con, $query);

$result=mysqli_query($con,$query) or die("Query Error...");

if($row=mysqli_fetch_array($result))
{
    $sid=$row['sid'];
    $sname=$row['sname'];
    $loc=$row['location'];
    $add=$row['address'];
    $ci=$row['cont_info'];

    }
else
     exit("<h2 class='msg'>Supplier Not Found</h2>");  
?>
	
<form action="act_supplier.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' bgcolor='aliceblue'>
<tr bgcolor='skyblue'><th colspan='2'> Supplier Profile</th></tr>
<tr>
<th>Supplier Id:</th>
<td><input type="text"  name="sid" value="<?php echo $sid; ?>" /></td>
</tr>
<tr>
<th>Supplier Name:</th>
<td><input type="text"  name="sname" value="<?php echo $sname; ?>" /></td>
</tr>
<th>Location:</th>
<td><input type="text"  name="loc"  value="<?php echo $location; ?>"/></td>
</tr>
<tr>
<th>Address:</th>
<td>
<textarea name="add" rows="3" cols="21" value="<?php echo $address; ?>"></textarea>
</td>
</tr>
<tr>
<th>ContactInfo:</th>
<td><input type="text"  name="ci" value="<?php echo $cont_info; ?>" /></td>
</tr>

<tr bgcolor='skyblue'>
<td colspan='2' align='center'> 
<input type="submit"  value="Update Supplier Profile" />
</td>
</tr>
</table>
</form>


<?php include_once  "footer.php" ?>



