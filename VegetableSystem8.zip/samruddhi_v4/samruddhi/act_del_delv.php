<?php 
include_once "header.php";  

$did=$_POST['did'];

require_once "db_conf.php";

$query="delete from delivery where did='$did'";

mysqli_query($con,$query) or die("<h3 style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
	echo "<h3 class='msg'>SUCCESS: Delivery  Deleted</h3>";
else
	echo "<h3 class='msg'>Oopsss: Record Not Found</h3>";
	
echo  "<p><a class='link' href='delv_list.php'>Back To List</a></p>";

include_once "footer.php";  
?>