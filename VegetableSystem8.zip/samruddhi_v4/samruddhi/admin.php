<?php include_once  "header.php";

if($g_role!='admin')
{
	exit("<h2 class='msg' style='color:red'>Access Denied. Please Login</h2>");
}
 ?>
<div class='msg'>
<h2>Welcome To Admin Action Panel</h2>
<ol style='text-align:left'>
<li><p>To View Member Profiles <a href='profile_list.php'>Click Here</a></p></li>
<li><p>To Manage Supplier <a href='sup_list.php'>Click Here</a></p></li>
<li><p>To Manage Supplier Orders <a href='sup_orders_list.php'>Click Here</a></p></li>
<li><p>To  Manage Vegetable Order   <a href='veg_list.php'>Click Here</a></p></li>
<li><p>To Manage Customer Orders <a href='admin_cust_order_list.php'>Click Here</a></p></li>
<li><p>To Manage Receipts <a href='recp_list.php'>Click Here</a></p></li>
<li><p>To Manage Delivery Orders <a href='delv_list.php'>Click Here</a></p></li>
<li><p>To Manage Feedback List <a href='feedback_list.php'>Click Here</a></p></li>
<li><p>To Manage All Report <a href='admin_all_report.php'>Click Here</a></p></li>

<!--<li><p>To View Customer Reports <a href='admin_reports.php'>Click Here</a></p></li>
<li><p>To View Supplier Reports <a href='admin_supplier_report.php'>Click Here</a></p></li>
<li><p>To View Vegetable Reports <a href='admin_vegetable_report.php'>Click Here</a></p></li>
<li><p>To View Receipt Reports <a href='admin_recp_report.php'>Click Here</a></p></li>
<li><p>To View Delivery Reports <a href='admin_delv_report.php'>Click Here</a></p></li>
-->


<li><p><a href='logout.php'>Logout</a></p></li>
</ol>
</div>
<?php include_once  "footer.php" ?>

