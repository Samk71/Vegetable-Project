<?php 
include_once "header.php";  

$oid=$_POST['oid'];
$uname=$_POST['uname'];

require_once "db_conf.php";

$query="update cust_order set uname='$uname' where oid='$oid'";

mysqli_query($con,$query) or die("<h3 class='msg' style='color:red'>Error: ".mysqli_error($con)."</h3>");

if(mysqli_affected_rows($con)>0)
	echo "<h3 class='msg'>SUCCESS: Customer Order Updated</h3>";
else
	echo "<h3 class='msg'>Oopsss: Nothing To Update</h3>";
	
echo  "<p><a class='link' href='cust_order_list.php'>Back To List</a></p>";

include_once "footer.php";  
?>