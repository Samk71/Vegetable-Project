<?php 
include_once "header.php";  
?>

<table border="1" cellpadding="15" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='9'>Customer Order List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>Order id</th><th>Order Date</th><th>Vegetable</th><th>Quantity</th><th>Rate</th><th>Payment</th><th>Action</th></tr>

<?php
require_once"db_conf.php";

$query="select * from v_cust_order where payment<>'UNPAID'  order by oid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
	$oid=$row['oid'];
    	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['oid']."</td>";
	echo "<td>".$row['odate']."</td>";
	echo "<td>".$row['vname']."</td>";
	echo "<td>".$row['qty']."</td>";
	echo "<td>".$row['rate']."</td>";
	echo "<td>".$row['payment']."</td>";
	echo "<td>";
	echo "<a href='act_admin_pay_cust_ord.php?oid=$oid&sts=Confirm'>Confirm</a>";
	echo "&nbsp;&nbsp;<a href='act_admin_pay_cust_ord.php?oid=$oid&sts=Pending'>Pending</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>