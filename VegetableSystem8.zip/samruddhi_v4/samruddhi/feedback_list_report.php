<!--<?php 
include_once "header.php";  
?>
-->
<center>
<h3>Online MadhuMitra Vegetables Web App</h3>
<a href='#' onclick="print();">Print</a><hr/>
<table border="1" cellpadding="15" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='silver'><th colspan='8'>Feedback List</th></tr>
<tr bgcolor='lightgrey'><th>SrNo</th><th>FID</th><th>FullName</th><th>Date</th><th>Mobile</th><th>Email</th><th>Feedback</th></tr>

<?php
require_once"db_conf.php";

$query="select * from feedback order by fid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
	$fid=$row['fid'];
    	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['fid']."</td>";
	echo "<td>".$row['fullname']."</td>";
	echo "<td>".$row['fodt']."</td>";
	echo "<td>".$row['mobile']."</td>";
	echo "<td>".$row['email']."</td>";
	echo "<td>".$row['feedback']."</td>";
    
           
	
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>