<?php include_once  "header.php";

 require_once "db_conf.php";

$query="select * from supplier order where sname='$g_user'";

$result = mysqli_query($con, $query);

$result=mysqli_query($con,$query) or die("Query Error...");

if($row=mysqli_fetch_array($result))
 {
    $soid=$row['soid'];
    $date=$row['date'];
    $vid=$row['vid'];
    $qty=$row['qty'];
    $sid=$row['sid'];

    }
else
     exit("<h2 class='msg'>Supplier Order Not Found</h2>"); 
?> 
	
<form action="sup_orders_list.php" method="post">
<table border='1' cellpadding='7' cellspacing='0' bgcolor='aliceblue'>
<tr bgcolor='skyblue'><th colspan='2'> Supplier Order</th></tr>
<tr>
<th>Supplier Order Id:</th>
<td><input type="text"  name="soid"  /></td>
</tr>
<tr>
<th>Date:</th>
<td><input type="date"  name="date"  /></td>
</tr>
<tr>
<th>VId:</th>
<td><input type="text"  name="vid"  /></td>
</tr>
<tr>
<th>Quantity:</th>
<td><input type="text"  name="qty"  /></td>
</tr>

<tr>
<th>SId:</th>
<td><input type="text"  name="sid"  /></td>
</tr>

<tr bgcolor='skyblue'>
<td colspan='2' align='center' padding='5'> 
<input type="submit"  value="Order" />
</td>
</tr>
</table>
</form>


<?php include_once  "footer.php" ?>



