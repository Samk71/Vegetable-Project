<?php include_once  "header.php";

if($g_role!='admin')
{
	exit("<h2 class='msg' style='color:red'>Access Denied. Please Login</h2>");
}
 ?>
<div class='msg'>
<h2>Welcome To Admin Reports</h2>
<ol style='text-align:left'>
<li><p>To View  Specific Vegetable Report <a href='veg_list_spe_report.php'>Click Here</a></p></li>
<li>
<form action='veg_list_spe_report.php'>
<p>
<fieldset >
<legend>Vegetable Specific Order Report:</legend><p> 
<form>
<th>Stock:</th>
<td> 
<select name="vname" style='width:150px' >
echo "<option value='$vname'>0-50</option>";
echo "<option value='$vname'>Onion</option>";
echo "<option value='$vname'>Potato</option>";
echo "<option value='$vname'>Palak</option>";
<p>
<input type="submit" value="Show Report"/>

</p>
</select>
</td>
</form>
</fieldset>

</li>
</ol>
</div>
<?php include_once  "footer.php" ?>