<?php 
include_once  "header.php"; 

if($g_role!='member')
{

	exit("<h2 class='msg' style='color:red'>Access Denied. Please Login</h2>");
}	
?>

<div class='msg'>
<h2>Welcome To Member Action Panel</h2>
<ol style='text-align:left'>
<li><p>To Edit Profile <a href='profile.php'>Click Here</a></p></li>
<li><p>To  Manage Vegetable Order   <a href='veg_list.php'>Click Here</a></p></li>
<li><p>To Manage Customer Orders    <a href='cust_order_list.php'>Click Here</a></p></li>
<li><p>To View Confirm Payment      <a href='confirm_cust_ord_list.php'>Click Here</a></p></li>
<li><p>To View Receipt List         <a href='member_recp_list.php'>Click Here</a></p></li>
<li><p>To View Delivery List        <a href='member_delv_list.php'>Click Here</a></p></li>
<li><p>To View Feedback List        <a href='feedback_list.php'>Click Here</a></p></li>

<li><p><a href='logout.php'>Logout</a></p></li>
</ol>
</div>
<?php include_once  "footer.php" ?>