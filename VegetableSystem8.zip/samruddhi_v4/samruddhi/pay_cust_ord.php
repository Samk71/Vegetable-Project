<?php 
include_once "header.php";  
$oid=$_GET['oid'];
echo "<h3 class='msg'>Payment For Order: $oid</h3>";
echo "<p><img src='images/qrc.jpeg' /></p>";
echo "<span class='link'><a href='act_pay_cust_ord.php?oid=$oid'>Pay</a></span>";
echo "<span class='link'><a href='cust_order_list.php'>Cancel</a></span>";
include_once "footer.php";  
?>
