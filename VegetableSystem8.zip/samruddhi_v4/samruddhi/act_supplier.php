<?php include_once  "header.php";

 $sid=$row['sid'];
 $sname=$row['sname'];
 $loc=$row['location'];
 $add=$row['address'];
 $ci=$row['cont_info'];

    echo "<p class='link'><a href='supplier.php'>Back</a></p>";

    require_once "db_conf.php";

    $query="update profile set sname='$sname',location='$loc',cont_info='$ci',address='$add' where sname='$g_user'";
    mysqli_query($con,$query) or die("<span class='msg' style='color:red'><Error: ".mysqli_error($con)."</span>");

    if(mysqli_affected_rows($con) > 0)
           echo "<h2 class='msg' style='color:green'>Success:Supplier Profile Updated</h2>";
    else
    echo "<p class='msg' style='color:red'>Opss:Supplier Profile Nothing Updated</p>";
include_once  "footer.php";?>