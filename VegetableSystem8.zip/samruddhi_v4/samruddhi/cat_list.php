<?php 
include_once "header.php";  
?>
<p>

<a class='link' href='new_cat.php'>New Category</a>
</p>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='khaki'><th colspan='3'>Category List</th></tr>
<tr bgcolor='skyblue'><th>SrNo</th><th>Category</th><th>Action</th></tr>

<?php
require_once"db_conf.php";

$query="select * from category order by cid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
 	$cid=$row['cid'];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['cname']."</td>";
               echo "<td><a href='edit_cat.php?cid=$cid'>Edit</a> <a href='del_cat.php?cid=$cid'>Delete</a></td>";
	echo "</tr>";
}

mysqli_close($con);
?>
<?php 
include_once "footer.php";  
?>