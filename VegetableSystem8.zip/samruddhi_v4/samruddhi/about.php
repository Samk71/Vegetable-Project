<?php include_once  "header.php" ?>
<h3 class="msg">Developed by Samruddhi Kamble</h3>
<?php include_once  "footer.php" ?>