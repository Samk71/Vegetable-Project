<?php
$frdt=$_GET['frdt'];
$todt=$_GET['todt'];
?>
<html>
<head>
<title>Customer  Report</title>
</head>
<body>
<center>
<h2>Online MadhuMitra Vegetable Web App</h2>
<a href='#' onclick="print();">Print</a><hr/>
<table border="1" cellpadding="10" cellspacing="0">
<tr bgcolor='silver'><th colspan='8'>Customer Report </th></tr>
<tr bgcolor='lightgrey'><th>SrNo</th><th>Customer</th><th>Order Id</th><th>Order Date</th><th>Vegetable</th><th>Quantity</th><th>Rate</th><th>Payment</th></tr>

<?php
require_once"db_conf.php";

$query="select * from v_Cust_order where odate between '$frdt' and '$todt' order by oid desc";

$result=mysqli_query($con,$query) or die("Query Error:".mysqli_error($con));

$srno=0;
while($row=mysqli_fetch_array($result))
{
	$srno++;
 	$oid=$row['oid'];
	echo "<tr>";
	echo "<td align='center'>$srno</td>";
	echo "<td>".$row['fn']."</td>"; 
	echo "<td>".$row['oid']."</td>"; 
	echo "<td>".$row['odate']."</td>";
	echo "<td>".$row['vname']."</td>";  
	echo "<td>".$row['qty']."</td>"; 
	echo "<td>".$row['rate']."</td>";  
	echo "<td>".$row['payment']."</td>"; 

	echo "</tr>";
}

mysqli_close($con);
?>
</center>
</body>
</html>