<?php include_once  "header.php";
$vid=$_POST['vid'];
$vname=$_POST['vname'];
$unit=$_POST['unit'];
$rate=$_POST['rate'];


echo "<p class='link'><a href='veg.php'>Back</a></p>";

require_once "db_conf.php";

$query="update veg profile set vname='$vname',unit='$unit',rate='$rate' where vname='$g_user'";

mysqli_query($con,$query) or die("<span class='msg' style='color:red'>Error: ".mysqli_error($con)."</span>");

if(mysqli_affected_rows($con) > 0) 
	echo "<h2 class='msg' style='color:green'>Success: Profile Updated</h2>";
else
	echo "<p class='msg' style='color:red'>Oopss:Nothing Updated</p>";

include_once  "footer.php";?>