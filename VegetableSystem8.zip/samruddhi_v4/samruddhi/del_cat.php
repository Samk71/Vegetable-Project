<?php 
include_once "header.php";  

$cid=$_GET['cid'];    // read query string

require_once "db_conf.php";

$query="select * from category where cid='$cid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$cname=$row['cname'];
}
else
	exit("<h2>Record Not Found</h2>");

?>

<h2 class='msg' style='color:red'>Delete Category: <?php echo $cname; ?></h2>

<p><a class='link' href='cat_list.php'>Back To List</a></p>
<form action='act_del_cat.php' method='post'>

<input type='hidden' name='cid' value="<?php echo $cid; ?>" /></td>
<h3 class='msg'>Are You Sure?</h3>
<input type='submit' value='Confirm Delete' />

</form>
<?php 
include_once "footer.php";  
?>