<?php
if(!isset($_SESSION))
	session_start();

$g_user=isset($_SESSION['user'])?$_SESSION['user']:"";
$g_role=isset($_SESSION['role'])?$_SESSION['role']:"";
?>
<html>
<head>
<link rel="stylesheet" href='mystyle.css' />
<title>Online MadhuMitra Vegetable Web App</title>
</head>
<body>
<center>
<h1> Online MadhuMitra Vegetables Web App </h1>
<?php
if($g_user!="")
	echo "<p class='msg'>Welcome $g_role $g_user</p>";
?>

<span class='link'><a href='index.php'>Home</a></span>
<span class='link'><a href='login.php'>Login</a></span>
<span class='link'><a href='about.php'>About</a></span>
<span class='link'><a href='contactus.php'>ContactUs</a></span>
<span class='link'><a href='feedback.php'>Feedback</a></span>
<?php
if($g_user!="")
	echo "<span class='link'><a href='$g_role.php'>Dashboard</a></span>";
?>
<div style="padding:20px">