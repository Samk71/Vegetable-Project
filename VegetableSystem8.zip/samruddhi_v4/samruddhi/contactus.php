<?php include_once  "header.php" ?>
<h3 class="msg">Phone    :8421964627</h3>
<h3 class="msg">Email    :madhumitra@gmail.com</h3>
<h3 class="msg">Address  :Near Vasantdada Market Yard Sangli</h3>
<h3 class="msg"> Website :http://madhumitra.com</h3>


<?php include_once  "footer.php" ?>