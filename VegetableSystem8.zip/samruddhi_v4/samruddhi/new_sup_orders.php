<?php 
include_once "header.php";  
require_once "db_conf.php";

$query="select * from supplier order by sname";
$supp_result=mysqli_query($con,$query) or die("Query Error");

$query="select * from veg order by vname";
$veg_result=mysqli_query($con,$query) or die("Query Error");
?>
<p><a class='link' href='sup_orders_list.php'>Back To List</a></p>
<form action='act_new_orders.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Order</th></tr>
<tr>
<th>OrderNo:</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Date</th>
<td><input type='date' name='date' required value="<?php echo date('Y-m-d')?>"/></td>
</tr>
<tr>
<th> Select Supplier Name:</th>
<td>
<select name='sid' style='width:98%'>
<?php
while($row=mysqli_fetch_array($supp_result))
{
	$sid=$row['sid'];
	$sn=$row['sname'];
	echo "<option value='$sid'>$sn</option>";
}
?>
</select>
</td>
</tr>
<tr>
<th>Select Vegetable:</th>
<td>
<select name='vid' style='width:98%'>
<?php
while($row=mysqli_fetch_array($veg_result))
{
	$vid=$row['vid'];
	$vn=$row['vname'];
	echo "<option value='$vid'>$vn</option>";
}
?>
</select>
</td>
</tr>
<tr>
<th>Quantity:</th>
<td><input type='text'  name='qty' required /></td>
</tr>
         

<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit' value='Add Order' />
</td>
</tr>

    
</table>
</form>
<?php 
include_once "footer.php";  
?>