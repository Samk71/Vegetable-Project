<?php 
include_once "header.php";  

$cid=$_GET['cid'];    // read query string

require_once "db_conf.php";

$query="select * from category where cid='$cid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$cname=$row['cname'];
}
else
	exit("<h2 class='msg'>Record Not Found</h2>");

?>

<p><a class='link' href='cat_list.php'>Back To List</a></p>
<form action='act_edit_cat.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr><th bgcolor='pink' colspan='2'>Edit Category</th></tr>
<tr>
<th>CID</th>
<td><input type='text' name='cid' value="<?php echo $cid; ?>" readonly /></td>
</tr>
<tr>
<th>Category</th>
<td><input type='text' name='cname'  value="<?php echo $cname; ?>"  required /></td>
</tr>
<tr bgcolor='skyblue'>
<td colspan='2' align='center'>
<input type='submit' value='Update Category' />
</td>
</tr>
</table>
</form>
<?php
include_once "footer.php";  
?>