<?php 
include_once "header.php";  
?>
<p><a class='link' href='sup_list.php'>Back To List</a></p>
<form action='act_new_sup.php' method='post'>
<table border="1" cellpadding="10" cellspacing="0" bgcolor="aliceblue">
<tr bgcolor='pink'><th colspan='2'>New Supplier</th></tr>
<tr>
<th>SID</th>
<td><i>AutoNumber</i></td>
</tr>
<tr>
<th>Supplier</th>
<td><input type='text' name='sname' required /></td>
</tr>
<tr>
<th>Location:</th>
<td><input type='text' name='loc' required /></td>
</tr>
<tr>
<th>Address:</th>
<td><input type='text' name='add'   required /></td>
</tr>
<tr>
<th>ContactInfo:</th>
<td><input type='text'  name='ci' required /></td>
</tr>


<tr bgcolor='pink'>
<td colspan='2' align='center'>
<input type='submit' value='Add Supplier' />
</td>
</tr>

    
</table>
</form>
<?php 
include_once "footer.php";  
?>