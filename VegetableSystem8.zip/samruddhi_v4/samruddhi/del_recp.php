<?php 
include_once "header.php";  

$rid=$_GET['rid'];    // read query string

require_once "db_conf.php";

$query="select * from receipts where rid='$rid'";

$result=mysqli_query($con,$query) or die("Error: ".mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$uname=$row['uname'];
}
else
	exit("<h2>Record Not Found</h2>");

?>

<h2 class='msg' style='color:red'>Delete Receipt: <?php echo $uname; ?></h2>

<p><a class='link' href='recp_list.php'>Back To List</a></p>
<form action='act_del_recp.php' method='post'>

<input type='hidden' name='rid' value="<?php echo $rid; ?>" /></td>
<h3 class='msg'>Are You Sure?</h3>
<input type='submit' value='Confirm Delete' />

</form>
<?php 
include_once "footer.php";  
?>